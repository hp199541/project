import React from 'react';
import ShowArea from './showarea'
import Button from './button'
import Color from './color'
function Connect (){
    return (
        <div>
            <Color>
            <ShowArea></ShowArea>
            <Button></Button>
            </Color>
        </div>
    )
}
export default Connect