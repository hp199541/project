import React from 'react'
export default class Index extends React.Component {
    render() {
        return (
            <div>
                首页
            </div>
        )
    }
}