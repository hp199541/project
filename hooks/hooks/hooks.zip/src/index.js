import React from 'react';
import App from './components/ref';
import ReactDOM from 'react-dom'
ReactDOM.render(<App></App>,document.getElementById('root'))